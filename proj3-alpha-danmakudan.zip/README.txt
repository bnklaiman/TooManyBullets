Brad Cosma (bcosma@wpi.edu)
Benny Klaiman (bnklaiman@wpi.edu)

platform: Windows 11, Visual Studio 2022
files: All code is in the folder 'vs-2019', all sprites are in the folder 'sprites'.
code structure: Based off of Saucer Shoot, but with significant alterations to fit bullet hell gameplay.
how to compile: Use VS2022 to build, Debug x64 profile